<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\TugasController;
use App\Http\Controllers\PeriodeController;
use App\Http\Controllers\KelompokController;
use App\Http\Controllers\ProgressController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\AdminRekapController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

route::get('/', function () {
    return redirect()->route('login');
});

// Dashboard umum (bisa diakses admin & anggota)
Route::get('/dashboard', [DashboardController::class, 'index'])
    ->middleware('auth')
    ->name('dashboard');


Route::get('/login', [AuthController::class, 'loginForm'])->name('login');
Route::post('/login', [AuthController::class, 'login']);
Route::post('/logout', [AuthController::class, 'logout'])->name('logout');





// dashboard admin
Route::middleware(['auth', 'role:admin'])->group(function () {
    // Route::get('dashboard', [DashboardController::class, 'index'])->name('dashboard');
    Route::post('/generate-periode', [DashboardController::class, 'generatePeriode'])
        ->name('admin.generate.periode')
        ->middleware('auth');

    Route::post('/users/{user}/make-admin', [UserController::class, 'makeAdmin'])
        ->name('users.makeAdmin');

    Route::resource('tugas', TugasController::class);
    Route::resource('users', UserController::class);
    Route::resource('periode', PeriodeController::class);
    Route::resource('kelompok', KelompokController::class);

    // khusus pindah anggota
    Route::post('/kelompok/pindah/{user}', [KelompokController::class, 'pindahAnggota'])->name('kelompok.pindah');
    Route::post('/users/{user}/add-task', [UserController::class, 'addTask'])->name('users.addTask');

    Route::get('/rekap-belum', [AdminRekapController::class, 'index'])->name('rekap.belum');
    Route::post('/rekap/ambil-tugas', [AdminRekapController::class, 'ambilTugas'])->name('rekap.ambilTugas');
    Route::post('/tugas/ambil/{periode}/{juz}/{tugasId}/{kelompokId}', [TugasController::class, 'ambilTambahan'])
        ->name('tugas.ambil');

    // Route::get('/laporan/{periodeId}', [App\Http\Controllers\LaporanController::class, 'index'])->name('laporan.index');
    // routes/web.php
    Route::get('/laporan/{periodeId?}', [App\Http\Controllers\LaporanController::class, 'index'])->name('laporan.index');

    Route::post('/laporan/{periodeId}/kirim', [App\Http\Controllers\LaporanController::class, 'kirim'])->name('laporan.kirim');
});

Route::middleware(['auth'])->group(function () {

    Route::resource('progress', ProgressController::class)->only(['index', 'create', 'store']);
    Route::get('/progress/create', [ProgressController::class, 'create'])->name('progress.create');
    Route::get('/get-surat/{juz}', [ProgressController::class, 'getSuratByJuz']);
    Route::get('/get-ayat/{juz}/{surat}', [ProgressController::class, 'getAyatBySurat']);
    Route::get('/tugas/generate/{periode}', [TugasController::class, 'generate'])->name('tugas.generate');


    Route::get('/profil', [App\Http\Controllers\ProfilController::class, 'index'])->name('profil.index');
    Route::post('/profil/password', [App\Http\Controllers\ProfilController::class, 'updatePassword'])->name('profil.updatePassword');
});
