@extends('layouts.app')

@section('content')
<div class="container">
    <h2>Daftar Kelompok & Tugas</h2>
    <div class="mb-4 p-3 bg-light rounded border">
        <strong>Progres Keseluruhan:</strong><br>
        Selesai {{ $juzSelesaiAll }} dari {{ $totalJuzAll }} juz 
        ({{ $persenAll }}%)
        <div class="progress mt-2" style="height: 20px;">
            <div class="progress-bar bg-success" role="progressbar" 
                style="width: {{ $persenAll }}%;" 
                aria-valuenow="{{ $persenAll }}" aria-valuemin="0" aria-valuemax="100">
                {{ $persenAll }}%
            </div>
        </div>
    </div>

    {{-- resources/views/admin/dashboard.blade.php --}}
    @if(auth()->user()->role === 'admin')
        <form action="{{ route('admin.generate.periode') }}" method="POST" class="mb-3">
            @csrf
            <div class="form-check mb-2">
                <input class="form-check-input" type="checkbox" name="kirim_wa" id="kirim_wa" value="1">
                <label class="form-check-label" for="kirim_wa">
                    Kirim Notifikasi WA
                </label>
            </div>
            <button type="submit" class="btn btn-primary">
                ➕ Generate Periode Baru
            </button>
        </form>
    @endif

    <div class="container mb-3">
        <form method="GET" action="{{ route('dashboard') }}">
            <div class="row">
                <div class="col-md-4"  style="text-align: left">
                    <select name="periode_id" class="form-select" onchange="this.form.submit()">
                        @foreach($periodes as $p)
                            <option value="{{ $p->id }}" {{ $periodeId == $p->id ? 'selected' : '' }}>
                                {{ $p->nama_periode }} ({{ \Carbon\Carbon::parse($p->tanggal_mulai)->translatedFormat('d/M/Y') }} - {{ \Carbon\Carbon::parse($p->tanggal_selesai)->translatedFormat('d/M/Y') }})
                                {{-- {{ $p->nama_periode }} {{ $p->tanggal_mulai }} - {{ $p->tanggal_selesai }}) --}}
                            </option>
                        @endforeach
                    </select>
                </div>
            </div>
        </form>
    </div>
    <div class="accordion" id="accordionKelompok">
        @foreach($kelompok as $k)
        @php
            // hitung rata-rata progress per kelompok
            $totalProgress = 0;
            $anggotaCount = $k->tugas->count();
            foreach ($k->tugas as $t) {
                $totalAyat = \App\Models\JuzAyat::where('juz', $t->juz)->sum(\DB::raw('ayat_sampai - ayat_dari + 1'));
                $sudahSetor = $t->progress->sum(fn($p) => $p->ayat_sampai - $p->ayat_dari + 1);
                $persen = $totalAyat > 0 ? ($sudahSetor / $totalAyat * 100) : 0;
                $totalProgress += $persen;
            }
            $kelompokProgress = $anggotaCount > 0 ? round($totalProgress / $anggotaCount, 2) : 0;
        @endphp

        <div class="accordion-item">
            <h2 class="accordion-header" id="heading{{ $k->id }}">
                <button class="accordion-button collapsed d-flex justify-content-between align-items-center" 
                    type="button" data-bs-toggle="collapse"
                    data-bs-target="#collapse{{ $k->id }}" aria-expanded="false" aria-controls="collapse{{ $k->id }}">
                    <span>{{ $k->nama_kelompok }} ({{ $k->persen }}%)  </span>
                    {{-- Progress bar kelompok --}}
                    <div class="progress ms-3 flex-grow-1" style="max-width: 200px; height: 15px; margin-right: 10px;">
                        <div class="progress-bar bg-success" role="progressbar" style="width: {{ $kelompokProgress }}%;">
                            {{ $kelompokProgress }}%
                        </div>
                    </div>
                    <span style="margin-right: 10px;">{{ $k->juz_selesai }} dari {{ $k->total_juz }} juz </span>
                </button>
            </h2>

            <div id="collapse{{ $k->id }}" class="accordion-collapse collapse" aria-labelledby="heading{{ $k->id }}"
                data-bs-parent="#accordionKelompok">
                <div class="accordion-body">
                    @if($k->tugas->count())
                        @foreach($k->tugas as $t)
                            @php
                                $totalAyat = \App\Models\JuzAyat::where('juz', $t->juz)->sum(\DB::raw('ayat_sampai - ayat_dari + 1'));
                                $sudahSetor = $t->progress->sum(fn($p) => $p->ayat_sampai - $p->ayat_dari + 1);
                                $persenAnggota = $totalAyat > 0 ? round(($sudahSetor / $totalAyat * 100), 2) : 0;
                            @endphp

                            <div class="card mb-2">
                                <div class="card-body d-flex flex-row align-items-center justify-content-between"
                                    data-bs-toggle="collapse" data-bs-target="#detail-{{ $t->id }}">
                                    <div>
                                        <strong>{{ $t->user->name }}</strong><br>
                                        📘 Juz {{ $t->juz }} <br>
                                        Periode: {{ $t->periode->nama_periode }}
                                    </div>

                                    {{-- Progress bulat anggota --}}
                                    <div class="progress-circle" data-progress="{{ $persenAnggota }}">
                                        <span>{{ $persenAnggota }}%</span>
                                    </div>
                                </div>
                            @if(Auth::user()->role==='admin')
                                {{-- Detail progress collapse --}}
                                <div id="detail-{{ $t->id }}" class="collapse">
                                    @if($t->progress && $t->progress->count())
                                        <ul class="list-group list-group-flush">
                                            @foreach($t->progress as $p)
                                                <li class="list-group-item d-flex justify-content-between align-items-center">
                                                    <span>
                                                        📖 {{ $p->nama_surat ?? 'Surat ?' }} :
                                                        {{ $p->ayat_dari }} - {{ $p->ayat_sampai }}
                                                    </span>
                                                    {{-- <span class="badge bg-{{ $p->status == 'selesai' ? 'success' : 'warning' }}">
                                                        {{ ucfirst($p->status) }}
                                                    </span> --}}
                                                </li>
                                                
                                            @endforeach
                                        </ul>
                                    @else
                                        <p class="text-muted m-2">Belum ada rincian progress</p>
                                    @endif
                                </div>
                            @endif
                            </div>
                        @endforeach
                    @else
                        <p class="text-muted">Belum ada tugas.</p>
                    @endif
                </div>
            </div>
        </div>
        @endforeach
    </div>

</div>
@endsection
@push('scripts')
<script>
document.addEventListener("DOMContentLoaded", function() {
    document.querySelectorAll('.progress-circle').forEach(function(el) {
        let persen = el.getAttribute('data-progress') || 0;
        // ubah persen ke derajat (360 * persen/100)
        let deg = (persen / 100) * 360 + 'deg';
        el.style.setProperty('--deg', deg);
    });
});
</script>
@endpush