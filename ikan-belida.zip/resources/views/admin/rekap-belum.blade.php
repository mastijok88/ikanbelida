@extends('layouts.app')

@section('content')
<div class="container mt-4">
    <h3>Rekap Sisa Tilawah</h3>
    <div class="alert alert-secondary">
        <i class="bi bi-info-circle"></i>
        Default menampilkan <strong>periode sebelumnya</strong>. 
        Silakan pilih periode lain dari dropdown untuk melihat rekap berbeda.
    </div>
    <form method="GET" action="{{ route('rekap.belum') }}" class="mb-3">
        <label for="periode_id">Periode:</label>
        <select name="periode_id" id="periode_id" onchange="this.form.submit()">
            @foreach ($periodes as $periode)
                <option value="{{ $periode->id }}" {{ $periodeId == $periode->id ? 'selected' : '' }}>
                    {{ $periode->nama_periode }}
                </option>
            @endforeach
        </select>
    </form>
    @foreach ($rekap as $r)
        <h5 class="mt-3">{{ $r['nama'] }}</h5>
        <table class="table table-sm table-bordered align-middle">
            <thead>
                <tr>
                    <th width="120">Juz</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                @forelse ($r['belum'] as $tugas)
                    <tr>
                        <td>Juz {{ $tugas->juz }}</td>
                        <td>
                            @if ($tugas->diambil_oleh)
                                <span class="text-success">diambil {{ $tugas->pengambil->name }}</span>
                            @else
                                <form action="{{ route('tugas.ambil', [
                                    'periode' => $periodeId,
                                    'juz' => $tugas->juz,
                                    'tugasId' => $tugas->id,
                                    'kelompokId' => $tugas->kelompok_id,
                                ]) }}" method="POST" style="display:inline;">
                                    @csrf
                                    <button type="submit" class="btn btn-sm btn-primary">
                                        Ambil
                                    </button>
                                </form>
                            @endif
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="2" class="text-center text-muted">Tidak ada tugas belum selesai</td>
                    </tr>
                @endforelse
            </tbody>
        </table>
    @endforeach
</div>
@endsection
