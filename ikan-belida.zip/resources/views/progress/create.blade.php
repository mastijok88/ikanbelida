@extends('layouts.app')

@section('content')
<div class="container">
    <h3>Tambah Progress Hafalan</h3>

    <form action="{{ route('progress.store') }}" method="POST">
        @csrf
        <div class="mb-3">
            <label for="tugas_id" class="form-label">Pilih Tugas (Juz)</label>
            <select name="tugas_id" id="tugas_id" class="form-select" required>
                <option value="">-- Pilih Tugas --</option>
                @foreach($tugas as $t)
                    <option value="{{ $t->id }}">
                        Periode {{ $t->periode->nama_periode ?? '' }} - 
                        Kelompok {{ $t->kelompok->nama_kelompok ?? '' }} - 
                        Juz {{ $t->juz }}
                    </option>
                @endforeach
            </select>
        </div>

        <div class="mb-3">
            <label for="surat" class="form-label">Surat</label>
            <select name="nama_surat" id="surat" class="form-select" required>
                <option value="">-- Pilih Surat --</option>
            </select>
        </div>

        <div class="row">
            <div class="col">
                <label for="ayat_dari" class="form-label">Ayat Dari</label>
                <input type="number" name="ayat_dari" id="ayat_dari" class="form-control" required>
            </div>
            <div class="col">
                <label for="ayat_sampai" class="form-label">Ayat Sampai</label>
                <input type="number" name="ayat_sampai" id="ayat_sampai" class="form-control" required>
            </div>
        </div>

        <div class="mt-3">
            <label class="form-label">Total Dibaca:</label>
            <input type="text" id="total_baca" class="form-control" readonly>
        </div>

        <button type="submit" class="btn btn-success">Simpan Progress</button>
    </form>
</div>
@endsection

@push('scripts')
<script>
document.addEventListener("DOMContentLoaded", function(){
    const tugasSelect = document.getElementById("tugas_id");
    const suratSelect = document.getElementById("surat");
    const dariInput = document.getElementById("ayat_dari");
    const sampaiInput = document.getElementById("ayat_sampai");
    const totalInput = document.getElementById("total_baca");

    // Saat pilih tugas (Juz)
    tugasSelect.addEventListener("change", function() {
        const selected = this.options[this.selectedIndex];
        if (!selected) return;

        // Ambil juz dari teks option (misal "Juz 2")
        const juz = selected.text.match(/Juz (\d+)/)[1];

        // reset surat
        suratSelect.innerHTML = `<option value="">-- Pilih Surat --</option>`;
        fetch(`/get-surat/${juz}`)
            .then(res => res.json())
            .then(data => {
                data.forEach(s => {
                    suratSelect.innerHTML += `<option value="${s.surat}">${s.surat}</option>`;
                });
            });
    });

    // Saat pilih surat
    suratSelect.addEventListener("change", function(){
        const selectedTugas = tugasSelect.options[tugasSelect.selectedIndex];
        if (!selectedTugas) return;

        const juz = selectedTugas.text.match(/Juz (\d+)/)[1];
        const surat = this.value;

        fetch(`/get-ayat/${juz}/${surat}`)
            .then(res => res.json())
            .then(data => {
                dariInput.value = data.dari;
                sampaiInput.value = data.sampai;
                totalInput.value = (data.sampai - data.dari + 1) + " ayat";
            });
    });

    // Hitung manual jika ayat diubah
    function hitung() {
        let d = parseInt(dariInput.value) || 0;
        let s = parseInt(sampaiInput.value) || 0;
        if (d > 0 && s >= d) {
            totalInput.value = (s - d + 1) + " ayat";
        } else {
            totalInput.value = "";
        }
    }
    dariInput.addEventListener("input", hitung);
    sampaiInput.addEventListener("input", hitung);
});
</script>
@endpush

