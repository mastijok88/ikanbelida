@extends('layouts.app')

@section('title', 'Dashboard Anggota')

@section('content')
<div class="card card-custom p-3">
    <h5>Progress Bacaan</h5>
    <p>Minggu ini: <strong>Juz 2</strong></p>
    <p>Status: <span class="badge bg-success">Selesai</span></p>
</div>
@endsection
