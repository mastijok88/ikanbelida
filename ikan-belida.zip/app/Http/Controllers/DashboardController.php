<?php

// app/Http/Controllers/DashboardController.php
namespace App\Http\Controllers;

use Carbon\Carbon;
use App\Models\User;
use App\Models\Tugas;
use App\Models\JuzAyat;
use App\Models\Periode;
use App\Models\Kelompok;
use App\Models\Progress;
use Illuminate\Http\Request;
use App\Helpers\WhatsappHelper;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;

class DashboardController extends Controller
{
    public function index(Request $request)
    {
        $user = Auth::user();

        // ambil semua periode
        $periodes = Periode::orderBy('id', 'desc')->get();

        // ambil periode_id dari request atau default ke periode terakhir
        $periodeId = $request->get('periode_id', $periodes->first()?->id);

        // ambil kelompok + tugas sesuai periode
        // $kelompok = Kelompok::with(['tugas' => function ($q) use ($periodeId) {
        //     $q->where('periode_id', $periodeId)->with('progress', 'user', 'periode');
        // }])->get();

        // ambil kelompok + hanya tugas utama sesuai periode
        $kelompok = Kelompok::with(['tugas' => function ($q) use ($periodeId) {
            $q->where('periode_id', $periodeId)
                ->where('is_additional', false) // ⬅️ filter hanya tugas utama
                ->with('progress', 'user', 'periode');
        }])->get();

        $kelompok = $kelompok->map(function ($item) {
            $totalJuz = $item->tugas->count();
            $juzSelesai = $item->tugas->filter(function ($tugas) {
                $progress = $tugas->progress->last(); // ambil progres terakhir
                return $progress && $progress->status === 'selesai';
            })->count();

            $persen = $totalJuz > 0 ? round(($juzSelesai / $totalJuz) * 100, 2) : 0;

            $item->total_juz = $totalJuz;
            $item->juz_selesai = $juzSelesai;
            $item->persen = $persen;

            return $item;
        });

        // Hitung total keseluruhan
        $totalJuzAll = $kelompok->sum('total_juz');
        $juzSelesaiAll = $kelompok->sum('juz_selesai');
        $persenAll = $totalJuzAll > 0 ? round(($juzSelesaiAll / $totalJuzAll) * 100, 2) : 0;

        return view('admin.dashboard', compact(
            'kelompok',
            'periodes',
            'periodeId',
            'totalJuzAll',
            'juzSelesaiAll',
            'persenAll'
        ));
    }



    // app/Http/Controllers/DashboardController.php

    public function generatePeriode(Request $request)
    {
        // 1. Buat periode baru
        $today = Carbon::now();
        $tanggalMulai  = $today->startOfWeek(Carbon::MONDAY);
        $tanggalSelesai = (clone $tanggalMulai)->endOfWeek(Carbon::SUNDAY);

        $lastPeriode = Periode::orderBy('nomor_pekan', 'desc')->first();

        if (!$lastPeriode) {
            // Kalau belum ada periode → mulai dari pekan 30
            $nextNumber = 30;
        } else {
            $nextNumber = $lastPeriode->nomor_pekan + 1;
        }

        $periodeBaru = Periode::create([
            'nomor_pekan'   => $nextNumber,
            'nama_periode'  => 'Pekan ' . $nextNumber,
            'tanggal_mulai' => $tanggalMulai,
            'tanggal_selesai' => $tanggalSelesai,
        ]);

        // 2. Ambil semua anggota
        $anggota = User::get();
        $jumlahAnggota = $anggota->count();

        // 3. Hitung kebutuhan kelompok
        $jumlahKelompokPenuh = intdiv($jumlahAnggota, 30);
        $sisa = $jumlahAnggota % 30;

        $totalKelompok = $jumlahKelompokPenuh + ($sisa > 0 ? 1 : 0);
        $kelompokIds = [];

        // Buat kelompok berdasarkan angka (Kelompok 1, 2, dst)
        for ($i = 1; $i <= $totalKelompok; $i++) {
            $nama = 'Kelompok ' . $i;
            $kelompok = Kelompok::firstOrCreate(['nama_kelompok' => $nama]);
            $kelompokIds[] = $kelompok->id;
        }


        //$index = 0;
        $jmlKelompok = count($kelompokIds);

        foreach ($anggota as $i => $user) {
            // tentukan kelompok berdasarkan index anggota
            $kelompokIndex = intdiv($i, 30); // tiap 30 orang ganti kelompok
            if ($kelompokIndex >= $jmlKelompok) {
                $kelompokIndex = $jmlKelompok - 1; // sisanya semua ke kelompok terakhir
            }

            $kelompokId = $kelompokIds[$kelompokIndex];

            // cek tugas sebelumnya (untuk lanjut ke juz berikutnya)
            $lastTask = Tugas::where('user_id', $user->id)
                ->latest('id')->first();

            // tentukan juz sesuai urutan
            $juz = $lastTask ? $lastTask->juz + 1 : (($i % 30) + 1);
            if ($juz > 30) $juz = 1;

            // assign tugas
            Tugas::create([
                'user_id'     => $user->id,
                'kelompok_id' => $kelompokId,
                'periode_id'  => $periodeBaru->id,
                'juz'         => $juz,
            ]);
        }


        // 5. Jika centang WA aktif, kirim notif
        if ($request->has('kirim_wa')) {
            $pesan = "📢 Periode baru telah dibuat!\n\n" .
                "Nama Periode: {$periodeBaru->nama_periode}\n" .
                "Tanggal: {$periodeBaru->tanggal_mulai->format('d M Y')} - {$periodeBaru->tanggal_selesai->format('d M Y')}\n\n" .
                "Silakan cek aplikasi untuk detail pembagian tugas.\n\n" .
                "https://ikan-belida.dedipartijo.biz.id";

            WhatsappHelper::send(env('WA_GROUP'), $pesan);
        }

        return back()->with('success', 'Periode baru & pembagian kelompok berhasil dibuat! Notifikasi WA sudah dikirim.');
    }
}
