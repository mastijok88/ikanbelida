<?php

namespace App\Http\Controllers;

use App\Models\Tugas;
use App\Models\JuzAyat;
use App\Models\Periode;
use App\Models\Progress;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Auth;

class ProgressController extends Controller
{
    public function index(Request $request)
    {
        $user = Auth::user();

        // Ambil semua periode (untuk dropdown)
        $periodes = Periode::orderBy('id')->get();

        // Default: pakai periode terakhir kalau tidak ada filter
        $selectedPeriodeId = $request->get('periode_id', $periodes->last()->id ?? null);

        // Ambil tugas user sesuai periode terpilih
        $tugas = Tugas::with('periode')
            ->where('user_id', $user->id)
            ->where('periode_id', $selectedPeriodeId)
            ->get();

        // Ambil progress sesuai periode
        $progress = Progress::with(['tugas.periode', 'tugas.kelompok'])
            ->where('user_id', $user->id)
            ->whereHas('tugas', function ($q) use ($selectedPeriodeId) {
                $q->where('periode_id', $selectedPeriodeId);
            })
            ->get();

        // Hitung persentase hafalan
        $totalAyatPerJuz = JuzAyat::select('juz', DB::raw('SUM(ayat_sampai - ayat_dari + 1) as total'))
            ->groupBy('juz')
            ->pluck('total', 'juz');

        foreach ($progress as $p) {
            if (!$p->tugas || !isset($p->tugas->juz)) {
                $p->persen = 0;
                continue;
            }

            $juz = $p->tugas->juz;
            $totalAyatJuz = (int) ($totalAyatPerJuz[$juz] ?? 0);

            $ayatTerkumpul = Progress::where('user_id', $p->user_id)
                ->whereHas('tugas', function ($q) use ($juz, $selectedPeriodeId) {
                    $q->where('juz', $juz)
                        ->where('periode_id', $selectedPeriodeId);
                })
                ->sum(DB::raw('ayat_sampai - ayat_dari + 1'));

            $p->persen = $totalAyatJuz > 0
                ? round(($ayatTerkumpul / $totalAyatJuz) * 100, 1)
                : 0;
        }

        return view('progress.index', compact(
            'progress',
            'user',
            'tugas',
            'periodes',
            'selectedPeriodeId'
        ));
    }




    public function create()
    {
        $user = Auth::user();

        // ambil daftar juz
        $juzAyat = JuzAyat::select('juz')->distinct()->orderBy('juz')->get();

        // ambil tugas user login
        $tugas = Tugas::with('periode', 'kelompok')
            ->where('user_id', $user->id)
            ->get();

        // ambil daftar surat & ayat dari tabel juz_ayat
        // $juzAyat = JuzAyat::all();

        return view('progress.create', compact('tugas', 'juzAyat'));
    }

    public function getSuratByJuz($juz)
    {
        $surat = JuzAyat::where('juz', $juz)
            ->select('surat')
            ->distinct()
            ->get();

        return response()->json($surat);
    }

    public function getAyatBySurat($juz, $surat)
    {
        $data = JuzAyat::where('juz', $juz)
            ->where('surat', $surat)
            ->first();

        return response()->json([
            'dari'   => $data->ayat_dari,
            'sampai' => $data->ayat_sampai
        ]);
    }

    public function store(Request $request)
    {
        $request->validate([
            'tugas_id'   => 'required',
            'ayat_dari'  => 'required|integer',
            'ayat_sampai' => 'required|integer',
        ]);
        // dd(auth()->id());

        $userId = auth()->id();
        // ambil juz dari tabel tugas
        $tugas = Tugas::findOrFail($request->tugas_id);
        $juz   = $tugas->juz;

        Progress::create([
            'user_id'    => auth()->id(), // ⬅️ wajib ditambahkan
            'tugas_id'   => $request->tugas_id,
            'nama_surat' => $request->nama_surat,
            'ayat_dari'  => $request->ayat_dari,
            'ayat_sampai' => $request->ayat_sampai,
            'status'     => 'proses',
        ]);

        // Ambil data juz dari tabel juz_ayat
        //dd($juz);
        //$juzData = JuzAyat::where('juz', $juz)->first();
        //$totalAyatJuz = $juzData->ayat_sampai - $juzData->ayat_dari + 1;

        // ambil total ayat dalam juz ini
        $totalAyatJuz = JuzAyat::where('juz', $juz)
            ->selectRaw('SUM(ayat_sampai - ayat_dari + 1) as total')
            ->value('total');

        // dd($totalAyatJuz);

        // Hitung ayat yang sudah disetor user pada juz ini
        // hitung total ayat yang sudah disetor user untuk juz ini
        $ayatTerkumpul = Progress::where('user_id', $userId)
            ->whereHas('tugas', function ($q) use ($juz) {
                $q->where('juz', $juz);
            })
            ->sum(DB::raw('ayat_sampai - ayat_dari + 1'));

        // Update status jika juz selesai
        if ($ayatTerkumpul >= $totalAyatJuz) {
            Progress::where('user_id', $userId)
                ->whereHas('tugas', function ($q) use ($juz) {
                    $q->where('juz', $juz);
                })
                ->update(['status' => 'selesai']);
        }

        return redirect()->route('progress.index')
            ->with('success', 'Progress berhasil ditambahkan.');
    }
}
