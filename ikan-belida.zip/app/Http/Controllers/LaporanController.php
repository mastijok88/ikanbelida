<?php

namespace App\Http\Controllers;

use App\Models\Tugas;
use App\Models\Periode;
use App\Helpers\WhatsappHelper;
use Illuminate\Support\Facades\Http;

class LaporanController extends Controller
{
    public function index($periodeId = null)
    {
        // Ambil semua periode untuk dropdown
        $periodes = Periode::orderBy('id', 'desc')->get();

        // Default: ambil periode terakhir kalau tidak ada parameter
        $periode = $periodeId
            ? Periode::with(['tugas.progress'])->findOrFail($periodeId)
            : $periodes->first();

        // Hitung total & selesai
        $totalJuz   = $periode->tugas->count();
        $selesai    = $periode->tugas->filter(fn($t) => optional($t->progress->last())->status === 'selesai')->count();
        $rasio      = $totalJuz > 0 ? round(($selesai / $totalJuz) * 100, 2) : 0;

        // Ambil periode sebelumnya
        $periodeSebelumnya = Periode::where('id', '<', $periode->id)->latest('id')->first();
        // $sapuBersih = [];
        // if ($periodeSebelumnya) {
        //     $sapuBersih = Tugas::with('kelompok')
        //         ->where('periode_id', $periodeSebelumnya->id)
        //         ->get()
        //         ->groupBy('kelompok.nama_kelompok')
        //         ->map(function ($tugas) {
        //             return $tugas->filter(fn($t) => optional($t->progress->last())->status === 'selesai')
        //                 ->pluck('juz')
        //                 ->values();
        //         });
        // }

        $sapuBersih = [];
        if ($periodeSebelumnya) {
            $sapuBersih = Tugas::with(['kelompok', 'progress', 'user'])
                ->where('periode_id', $periodeSebelumnya->id)
                ->get()
                ->groupBy('kelompok.nama_kelompok')
                ->map(function ($tugas) {
                    return $tugas->map(function ($t) {
                        $progress = $t->progress->last();
                        $status   = $progress?->status;

                        if ($status === 'selesai') {
                            return "{$t->juz} : ✅ selesai";
                        }

                        if ($t->is_additional && $status === 'proses') {
                            return "{$t->juz} : 🚧 diproses (oleh {$t->user->name})";
                        }

                        if (!$progress && $t->is_additional) {
                            return "{$t->juz} : ⏳ belum mulai (oleh {$t->user->name})";
                        }

                        return null;
                    })
                        ->filter() // buang null
                        ->values();
                });
        }

        // Susun teks laporan
        $laporan = "Laporan Pelaksanaan Tilawah {$periode->nama_periode}\n\n";
        $laporan .= "A. Hasil {$periode->nama_periode}\n";
        $laporan .= "Alhamdulillah pada {$periode->nama_periode} kita telah menunaikan tilawah {$selesai} Juz dari {$totalJuz} Juz di "
            . $periode->tugas->groupBy('kelompok_id')->count() . " Grup atau rasio terbaca sebesar {$rasio}%.\n";
        $laporan .= "Tahniah untuk kita semua, semoga berkah. Kekurangan " . ($totalJuz - $selesai) . " Juz in syaa Alloh akan ditunaikan dalam pekan ini oleh Tim Admin Sapu Bersih Sisa Tilawah.\n\n";

        if ($periodeSebelumnya) {
            $laporan .= "B. Penyelesaian Sisa Tilawah {$periodeSebelumnya->nama_periode}\n";
            $laporan .= "Alhamdulillah sisa kekurangan tilawah {$periodeSebelumnya->nama_periode} telah ditunaikan oleh Tim Admin Saber Sawah sbb:\n";
            foreach ($sapuBersih as $grup => $juzList) {
                $laporan .= "{$grup} :\n";
                if ($juzList->isEmpty()) {
                    $laporan .= "Tidak ada\n";
                } else {
                    foreach ($juzList as $j) {
                        $laporan .= "Juz {$j} \n";
                    }
                }
            }
            $laporan .= "\nTerima kasih Tim Admin Saber Sawah, semoga berkah bagi semua.";
        }

        return view('laporan.index', compact('periode', 'periodes', 'laporan'));
    }


    public function kirim($periodeId)
    {
        $periode = Periode::findOrFail($periodeId);
        $laporan = $this->index($periodeId)->getData()['laporan'];

        // Kirim WA via Fonnte
        // $response = Http::withHeaders([
        //     'Authorization' => env('FONNTE_TOKEN'),
        // ])->post('https://api.fonnte.com/send', [
        //     'target' => env('FONNTE_GROUP_ID'), // nomor/group tujuan
        //     'message' => $laporan,
        // ]);

        WhatsappHelper::send(env('WA_GROUP'), $laporan);

        return back()->with('success', 'Laporan berhasil dikirim ke grup WA!');
    }
}
