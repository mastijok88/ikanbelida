<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Tugas;
use App\Models\Periode;
use App\Models\Kelompok;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class UserController extends Controller
{
    public function index(Request $request)
    {
        $query = User::query();

        // Fitur pencarian
        if ($request->has('search')) {
            $query->where(function ($q) use ($request) {
                $q->where('name', 'like', '%' . $request->search . '%')
                    ->orWhere('no_hp', 'like', '%' . $request->search . '%');
            });
        }

        // Pagination 10 data per halaman
        $users = $query->paginate(10);

        return view('users.index', compact('users'));
    }

    public function create()
    {
        $kelompok = Kelompok::all();
        return view('users.create', compact('kelompok'));
    }

    public function show()
    {
        // $kelompok = Kelompok::all();
        // return view('users.create', compact('kelompok'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required',
            'no_hp' => 'required|unique:users',
        ]);

        User::create([
            'name' => $request->name,
            'no_hp' => $request->no_hp,
            'password' => Hash::make('password'),
        ]);

        return redirect()->route('users.index')->with('success', 'User berhasil ditambahkan.');
    }

    public function edit(User $user)
    {
        $kelompok = Kelompok::all();
        return view('users.edit', compact('user', 'kelompok'));
    }

    public function update(Request $request, User $user)
    {
        $request->validate([
            'name' => 'required',
            'no_hp' => 'required|unique:users,no_hp,' . $user->id,
            'role' => 'required',
        ]);

        $user->update([
            'name' => $request->name,
            'no_hp' => $request->no_hp,
            'role' => $request->role,
        ]);

        return redirect()->route('users.index')->with('success', 'User berhasil diupdate.');
    }

    public function destroy(User $user)
    {
        $user->delete();
        return redirect()->route('users.index')->with('success', 'User berhasil dihapus.');
    }

    public function makeAdmin(User $user)
    {
        // hanya admin boleh akses
        if (auth()->user()->role !== 'admin') {
            abort(403, 'Tidak diizinkan.');
        }

        $user->update([
            'role' => 'admin'
        ]);

        return back()->with('success', "{$user->name} sekarang menjadi admin.");
    }

    public function addTask(User $user)
    {
        // cari periode aktif
        $periode = Periode::latest()->first();
        if (!$periode) {
            return back()->with('error', 'Belum ada periode aktif.');
        }

        // cari kelompok dengan jumlah anggota paling sedikit
        $kelompok = Kelompok::withCount(['tugas' => function ($q) use ($periode) {
            $q->where('periode_id', $periode->id);
        }])->orderBy('tugas_count', 'asc')->first();

        if (!$kelompok) {
            return back()->with('error', 'Belum ada kelompok.');
        }

        // cek apakah user sudah punya tugas di periode ini
        $cek = Tugas::where('user_id', $user->id)
            ->where('periode_id', $periode->id)
            ->first();
        if ($cek) {
            return back()->with('warning', 'User ini sudah punya tugas di periode ini.');
        }

        // ambil juz terakhir dari tugas sebelumnya
        $lastTask = Tugas::where('user_id', $user->id)->latest('id')->first();
        $juz = $lastTask ? $lastTask->juz + 1 : 1;
        if ($juz > 30) $juz = 1;

        // buat tugas baru
        Tugas::create([
            'user_id'     => $user->id,
            'kelompok_id' => $kelompok->id,
            'periode_id'  => $periode->id,
            'juz'         => $juz,
        ]);

        return back()->with('success', "Tugas untuk {$user->name} berhasil ditambahkan ke {$kelompok->nama_kelompok}.");
    }
}
