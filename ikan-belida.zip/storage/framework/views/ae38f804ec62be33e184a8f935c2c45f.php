

<?php $__env->startSection('content'); ?>
<div class="container">
    <h3>Laporan <?php echo e($periode->nama_periode); ?></h3>

    
    <form method="GET" action="<?php echo e(route('laporan.index')); ?>" class="mb-3">
        <label for="periode">Pilih Periode:</label>
        <select id="periode" name="periodeId" class="form-select d-inline-block w-auto"
                onchange="window.location.href='<?php echo e(route('laporan.index')); ?>/'+this.value">
            <?php $__currentLoopData = $periodes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($p->id); ?>" <?php echo e($p->id == $periode->id ? 'selected' : ''); ?>>
                    <?php echo e($p->nama_periode); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </form>

    <div class="card mb-3">
    <div class="card-body">
        <div style="white-space: pre-line; word-break: break-word;">
            <?php echo e($laporan); ?>

        </div>
    </div>
</div>

    <form action="<?php echo e(route('laporan.kirim', $periode->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <button type="submit" class="btn btn-success">Kirim ke Grup WA</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\ikan-belida\resources\views/laporan/index.blade.php ENDPATH**/ ?>