

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Detail Kelompok: <?php echo e($kelompok->nama_kelompok); ?></h2>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <table class="table">
        <thead>
            <tr>
                <th>Nama Anggota</th>
                <th>Nomor HP</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($user->name); ?></td>
                    <td><?php echo e($user->no_hp ?? '-'); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="2" class="text-muted">Belum ada anggota di periode ini</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>


    <a href="<?php echo e(route('kelompok.index')); ?>" class="btn btn-secondary">Kembali</a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\ikan-belida\resources\views/kelompok/show.blade.php ENDPATH**/ ?>