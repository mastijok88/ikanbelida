

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Daftar Kelompok & Tugas</h2>
    <div class="mb-4 p-3 bg-light rounded border">
        <strong>Progres Keseluruhan:</strong><br>
        Selesai <?php echo e($juzSelesaiAll); ?> dari <?php echo e($totalJuzAll); ?> juz 
        (<?php echo e($persenAll); ?>%)
        <div class="progress mt-2" style="height: 20px;">
            <div class="progress-bar bg-success" role="progressbar" 
                style="width: <?php echo e($persenAll); ?>%;" 
                aria-valuenow="<?php echo e($persenAll); ?>" aria-valuemin="0" aria-valuemax="100">
                <?php echo e($persenAll); ?>%
            </div>
        </div>
    </div>

    
    <?php if(auth()->user()->role === 'admin'): ?>
        <form action="<?php echo e(route('admin.generate.periode')); ?>" method="POST" class="mb-3">
            <?php echo csrf_field(); ?>
            <div class="form-check mb-2">
                <input class="form-check-input" type="checkbox" name="kirim_wa" id="kirim_wa" value="1">
                <label class="form-check-label" for="kirim_wa">
                    Kirim Notifikasi WA
                </label>
            </div>
            <button type="submit" class="btn btn-primary">
                ➕ Generate Periode Baru
            </button>
        </form>
    <?php endif; ?>

    <div class="container mb-3">
        <form method="GET" action="<?php echo e(route('dashboard')); ?>">
            <div class="row">
                <div class="col-md-4"  style="text-align: left">
                    <select name="periode_id" class="form-select" onchange="this.form.submit()">
                        <?php $__currentLoopData = $periodes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($p->id); ?>" <?php echo e($periodeId == $p->id ? 'selected' : ''); ?>>
                                <?php echo e($p->nama_periode); ?> (<?php echo e(\Carbon\Carbon::parse($p->tanggal_mulai)->translatedFormat('d/M/Y')); ?> - <?php echo e(\Carbon\Carbon::parse($p->tanggal_selesai)->translatedFormat('d/M/Y')); ?>)
                                
                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
        </form>
    </div>
    <div class="accordion" id="accordionKelompok">
        <?php $__currentLoopData = $kelompok; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
            // hitung rata-rata progress per kelompok
            $totalProgress = 0;
            $anggotaCount = $k->tugas->count();
            foreach ($k->tugas as $t) {
                $totalAyat = \App\Models\JuzAyat::where('juz', $t->juz)->sum(\DB::raw('ayat_sampai - ayat_dari + 1'));
                $sudahSetor = $t->progress->sum(fn($p) => $p->ayat_sampai - $p->ayat_dari + 1);
                $persen = $totalAyat > 0 ? ($sudahSetor / $totalAyat * 100) : 0;
                $totalProgress += $persen;
            }
            $kelompokProgress = $anggotaCount > 0 ? round($totalProgress / $anggotaCount, 2) : 0;
        ?>

        <div class="accordion-item">
            <h2 class="accordion-header" id="heading<?php echo e($k->id); ?>">
                <button class="accordion-button collapsed d-flex justify-content-between align-items-center" 
                    type="button" data-bs-toggle="collapse"
                    data-bs-target="#collapse<?php echo e($k->id); ?>" aria-expanded="false" aria-controls="collapse<?php echo e($k->id); ?>">
                    <span><?php echo e($k->nama_kelompok); ?> (<?php echo e($k->persen); ?>%)  </span>
                    
                    <div class="progress ms-3 flex-grow-1" style="max-width: 200px; height: 15px; margin-right: 10px;">
                        <div class="progress-bar bg-success" role="progressbar" style="width: <?php echo e($kelompokProgress); ?>%;">
                            <?php echo e($kelompokProgress); ?>%
                        </div>
                    </div>
                    <span style="margin-right: 10px;"><?php echo e($k->juz_selesai); ?> dari <?php echo e($k->total_juz); ?> juz </span>
                </button>
            </h2>

            <div id="collapse<?php echo e($k->id); ?>" class="accordion-collapse collapse" aria-labelledby="heading<?php echo e($k->id); ?>"
                data-bs-parent="#accordionKelompok">
                <div class="accordion-body">
                    <?php if($k->tugas->count()): ?>
                        <?php $__currentLoopData = $k->tugas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $totalAyat = \App\Models\JuzAyat::where('juz', $t->juz)->sum(\DB::raw('ayat_sampai - ayat_dari + 1'));
                                $sudahSetor = $t->progress->sum(fn($p) => $p->ayat_sampai - $p->ayat_dari + 1);
                                $persenAnggota = $totalAyat > 0 ? round(($sudahSetor / $totalAyat * 100), 2) : 0;
                            ?>

                            <div class="card mb-2">
                                <div class="card-body d-flex flex-row align-items-center justify-content-between"
                                    data-bs-toggle="collapse" data-bs-target="#detail-<?php echo e($t->id); ?>">
                                    <div>
                                        <strong><?php echo e($t->user->name); ?></strong><br>
                                        📘 Juz <?php echo e($t->juz); ?> <br>
                                        Periode: <?php echo e($t->periode->nama_periode); ?>

                                    </div>

                                    
                                    <div class="progress-circle" data-progress="<?php echo e($persenAnggota); ?>">
                                        <span><?php echo e($persenAnggota); ?>%</span>
                                    </div>
                                </div>
                            <?php if(Auth::user()->role==='admin'): ?>
                                
                                <div id="detail-<?php echo e($t->id); ?>" class="collapse">
                                    <?php if($t->progress && $t->progress->count()): ?>
                                        <ul class="list-group list-group-flush">
                                            <?php $__currentLoopData = $t->progress; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li class="list-group-item d-flex justify-content-between align-items-center">
                                                    <span>
                                                        📖 <?php echo e($p->nama_surat ?? 'Surat ?'); ?> :
                                                        <?php echo e($p->ayat_dari); ?> - <?php echo e($p->ayat_sampai); ?>

                                                    </span>
                                                    
                                                </li>
                                                
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    <?php else: ?>
                                        <p class="text-muted m-2">Belum ada rincian progress</p>
                                    <?php endif; ?>
                                </div>
                            <?php endif; ?>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <p class="text-muted">Belum ada tugas.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script>
document.addEventListener("DOMContentLoaded", function() {
    document.querySelectorAll('.progress-circle').forEach(function(el) {
        let persen = el.getAttribute('data-progress') || 0;
        // ubah persen ke derajat (360 * persen/100)
        let deg = (persen / 100) * 360 + 'deg';
        el.style.setProperty('--deg', deg);
    });
});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\ikan-belida\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>