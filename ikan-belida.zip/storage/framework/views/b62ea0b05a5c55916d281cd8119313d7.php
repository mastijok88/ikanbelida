

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2 class="mb-4">Daftar Anggota</h2>
    <p>Total: <strong><?php echo e($users->total()); ?></strong> anggota</p> 

    <a href="<?php echo e(route('users.create')); ?>" class="btn btn-primary mb-3">+ Tambah Anggota</a>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <!-- Form Pencarian -->
    <form method="GET" action="<?php echo e(route('users.index')); ?>" class="mb-3">
        <div class="input-group">
            <input type="text" name="search" class="form-control" placeholder="Cari nama, email, atau no HP" value="<?php echo e(request('search')); ?>">
            <button class="btn btn-primary" type="submit">Cari</button>
        </div>
    </form>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>No</th>
                <th>Nama</th>
                
                <th>No HP</th>
                <th>Role</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($users->firstItem() + $index); ?></td>
                    <td><?php echo e($user->name); ?></td>
                    
                    <td><?php echo e($user->no_hp); ?></td>
                    <td><?php echo e($user->role); ?></td>
                    <td>
                        <div class="dropdown">
                            <button class="btn btn-sm btn-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                <i class="bi bi-list"></i> 
                            </button>
                            <ul class="dropdown-menu">
                                <!-- Edit -->
                                <li>
                                    <a href="<?php echo e(route('users.edit', $user->id)); ?>" class="dropdown-item">
                                        ✏️ Edit
                                    </a>
                                </li>

                                <!-- Hapus -->
                                <li>
                                    <form action="<?php echo e(route('users.destroy', $user->id)); ?>" method="POST" onsubmit="return confirm('Hapus user ini?')">
                                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="dropdown-item text-danger">
                                            🗑 Hapus
                                        </button>
                                    </form>
                                </li>

                                <!-- Jadikan Admin -->
                                <?php if(auth()->user()->role === 'admin' && $user->role !== 'admin'): ?>
                                    <li>
                                        <form action="<?php echo e(route('users.makeAdmin', $user->id)); ?>" method="POST" onsubmit="return confirm('Jadikan admin?')">
                                            <?php echo csrf_field(); ?>
                                            <button type="submit" class="dropdown-item">
                                                ⭐ Jadikan Admin
                                            </button>
                                        </form>
                                    </li>
                                <?php endif; ?>

                                <!-- Tambahkan Tugas -->
                                <?php
                                    $periodeAktif = \App\Models\Periode::latest()->first();
                                    $sudahPunyaTugas = $periodeAktif
                                        ? \App\Models\Tugas::where('user_id', $user->id)
                                            ->where('periode_id', $periodeAktif->id)
                                            ->exists()
                                        : false;
                                ?>

                                <?php if(!$sudahPunyaTugas): ?>
                                    <li>
                                        <form action="<?php echo e(route('users.addTask', $user->id)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <button type="submit" class="dropdown-item">
                                                📖 Tambahkan Tugas
                                            </button>
                                        </form>
                                    </li>
                                <?php endif; ?>
                            </ul>
                        </div>
                    </td>

                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="5" class="text-center">Tidak ada data</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

    <!-- Pagination -->
    <div class="d-flex justify-content-center">
        <?php echo e($users->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\ikan-belida\resources\views/users/index.blade.php ENDPATH**/ ?>