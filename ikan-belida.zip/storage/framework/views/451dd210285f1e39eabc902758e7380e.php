

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2 class="mb-4">Progress Hafalan</h2>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    
    <form method="GET" action="<?php echo e(route('progress.index')); ?>" class="mb-3">
        <label for="periode_id">Pilih Periode:</label>
        <select name="periode_id" id="periode_id" class="form-select d-inline w-auto" onchange="this.form.submit()">
            <?php $__currentLoopData = $periodes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $periode): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($periode->id); ?>" <?php echo e($selectedPeriodeId == $periode->id ? 'selected' : ''); ?>>
                    <?php echo e($periode->nama_periode); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </form>

    
    <h5>Daftar Tugas</h5>
    <table class="table table-bordered mb-5">
        <thead>
            <tr>
                <th>Periode</th>
                <th>Tugas</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $tugas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($t->periode->nama_periode); ?></td>
                    <td>Juz <?php echo e($t->juz); ?>

                        <?php if($t->is_additional): ?>
                            <span class="badge bg-primary ms-2">Add</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php
                            $progressSelesai = $t->progress()->where('status', 'selesai')->count();
                            $progressTotal   = $t->progress()->count();
                        ?>

                        <?php if($progressTotal == 0): ?>
                            <span class="badge bg-secondary">Belum Mulai</span>
                        <?php elseif($progressSelesai > 0 && $progressSelesai == $progressTotal): ?>
                            <span class="badge bg-primary">Selesai</span>
                        <?php else: ?>
                            <span class="badge bg-success">Sedang Berjalan</span>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="3" class="text-center">Belum ada tugas di periode ini</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

    
    <a href="<?php echo e(route('progress.create')); ?>" class="btn btn-primary mb-3">+ Tambah Progress</a>

    
    <h5>Rincian Progress</h5>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Periode</th>
                <th>Tugas</th>
                <th>Nama Surat</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $progress; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($p->tugas->periode->nama_periode); ?></td>
                    <td>Juz <?php echo e($p->tugas->juz); ?></td>
                    <td><?php echo e($p->nama_surat); ?>, dari ayat 
                        <?php echo e($p->ayat_dari); ?> s.d. ayat
                        <?php echo e($p->ayat_sampai); ?>

                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="3" class="text-center">Belum ada progress</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\ikan-belida\resources\views/progress/index.blade.php ENDPATH**/ ?>