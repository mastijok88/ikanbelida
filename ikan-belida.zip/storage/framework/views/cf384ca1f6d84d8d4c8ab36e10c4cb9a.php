

<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <h3>Rekap Sisa Tilawah</h3>
    <div class="alert alert-secondary">
        <i class="bi bi-info-circle"></i>
        Default menampilkan <strong>periode sebelumnya</strong>. 
        Silakan pilih periode lain dari dropdown untuk melihat rekap berbeda.
    </div>
    <form method="GET" action="<?php echo e(route('rekap.belum')); ?>" class="mb-3">
        <label for="periode_id">Periode:</label>
        <select name="periode_id" id="periode_id" onchange="this.form.submit()">
            <?php $__currentLoopData = $periodes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $periode): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($periode->id); ?>" <?php echo e($periodeId == $periode->id ? 'selected' : ''); ?>>
                    <?php echo e($periode->nama_periode); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </form>
    <?php $__currentLoopData = $rekap; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <h5 class="mt-3"><?php echo e($r['nama']); ?></h5>
        <table class="table table-sm table-bordered align-middle">
            <thead>
                <tr>
                    <th width="120">Juz</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $r['belum']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tugas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td>Juz <?php echo e($tugas->juz); ?></td>
                        <td>
                            <?php if($tugas->diambil_oleh): ?>
                                <span class="text-success">diambil <?php echo e($tugas->pengambil->name); ?></span>
                            <?php else: ?>
                                <form action="<?php echo e(route('tugas.ambil', [
                                    'periode' => $periodeId,
                                    'juz' => $tugas->juz,
                                    'tugasId' => $tugas->id,
                                    'kelompokId' => $tugas->kelompok_id,
                                ])); ?>" method="POST" style="display:inline;">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="btn btn-sm btn-primary">
                                        Ambil
                                    </button>
                                </form>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="2" class="text-center text-muted">Tidak ada tugas belum selesai</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\ikan-belida\resources\views/admin/rekap-belum.blade.php ENDPATH**/ ?>