

<?php $__env->startSection('content'); ?>
<div class="container">
    <h3>Profil Anggota</h3>
    <div class="card mb-3">
        <div class="card-body">
            <p><strong>Nama:</strong> <?php echo e($user->name); ?></p>
            <p><strong>Nomor HP:</strong> <?php echo e($user->no_hp ?? '-'); ?></p>
            <p><strong>Menjadi Anggota Sejak:</strong> <?php echo e($user->created_at->format('d M Y')); ?></p>
            <p><strong>Status:</strong> 
                <?php if($user->is_admin): ?>
                    <span class="badge bg-success">Admin</span>
                <?php else: ?>
                    <span class="badge bg-secondary">Anggota</span>
                <?php endif; ?>
            </p>
        </div>
    </div>

    <h4>Ubah Password</h4>
    <div class="card">
        <div class="card-body">
            <?php if(session('success')): ?>
                <div class="alert alert-success"><?php echo e(session('success')); ?></div>
            <?php endif; ?>

            <form action="<?php echo e(route('profil.updatePassword')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="mb-3">
                    <label>Password Baru</label>
                    <input type="password" name="password" class="form-control" required>
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="text-danger"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="mb-3">
                    <label>Konfirmasi Password Baru</label>
                    <input type="password" name="password_confirmation" class="form-control" required>
                </div>

                <button type="submit" class="btn btn-primary">Update Password</button>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\ikan-belida\resources\views/profil/index.blade.php ENDPATH**/ ?>