

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2 class="mb-4">Daftar Kelompok</h2>

    <div class="card shadow-sm">
        <div class="card-body">
            <table class="table table-hover align-middle">
                <thead class="table-light">
                    <tr>
                        <th>#</th>
                        <th>Nama Kelompok</th>
                        <th>Jumlah Anggota</th>
                        <th class="text-end">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $kelompok; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><strong><?php echo e($k->nama_kelompok); ?></strong></td>
                        
                        <td><?php echo e($k->tugas->pluck('user')->unique('id')->count()); ?></td>
                        <td class="text-end">
                            <a href="<?php echo e(route('kelompok.show', $k->id)); ?>" class="btn btn-sm btn-primary">
                                <i class="bi bi-eye"></i> Lihat
                            </a>
                            
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\ikan-belida\resources\views/kelompok/index.blade.php ENDPATH**/ ?>